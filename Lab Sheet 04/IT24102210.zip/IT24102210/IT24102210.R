#question 1
setwd("C:\\Users\\IT24102210\\Desktop\\Labsheet -04")
getwd()
branch_data <- read.table("Exercise.txt", header=TRUE,sep=",")
head(data)


#question 2
str(branch_data)


#question 3
boxplot(branch_data$Sales_X1,
        main = "Boxplot of Sales",
        ylab = "Sales")

#question 4
fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#question 5
find_outliers <- function(x) {
  Q1 <- quantile(x,0.25)
  Q3 <- quantile(x,0.75)
  IQR_value <- Q3-Q1
  lower <- Q1 - 1.5 * IQR_value
  upper <- Q3 +1.5 * IQR_value
  outliers <- x[x<lower | x>upper]
  return(outliers)
}
find_outliers(branch_data$Years_X3)