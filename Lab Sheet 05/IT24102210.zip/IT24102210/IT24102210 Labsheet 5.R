setwd("C:\\Users\\IT24102210\\Desktop\\IT24102210")
getwd()

delivery_times <-read.table("Exercise - Lab 05.txt",header =TRUE)

head(delivery_times)

hist(
  delivery_times$Delivery_Time_.minutes.,
  main = "Histogram for Delivery Times",
  breaks = seq(20, 70, length = 10),   
  right = FALSE,
  col = "lightblue",
  xlab = "Delivery Time",
  ylab = "Frequency"
)

#question 03
#as the bars are higher in the middle, it is considered a sa bell shape graph.

histogram <- hist(delivery_times$Delivery_Time_.minutes., breaks=seq(20,70,length=10), plot=FALSE)
breaks<- round(histogram$breaks)
freq<- histogram$counts
cum.freq <-cumsum(freq)
mids <- histogram$mids

classes <-c()
for(i in 1:(length(breaks)-1)){
  classes[i] <- paste0("[", breaks[i], ",", breaks[i+1], ")")
}


cbind(Classes = classes,Feequency=freq)

new <- c(0, cum.freq)    
x_vals <- breaks          

#drawing cumulative frequency polygon
plot(x_vals, new, type='o',
     main="Cumulative Frequency Polygon of Delivery Times",
     xlab="Delivery Times", ylab="Cumulative Frequency",
     ylim=c(0, max(new)),
     col="pink", lwd=2, pch=16)

#obtain upper limit of each class along with its cumulative frequency in a table
cbind(Upper = breaks, CumFreq = new)
