setwd("C:\\Users\\IT24102210\\Desktop\\IT24102210")
data<-read.table("Data - Lab 8.txt",header=TRUE)
fix(data)
attach(data)

#computing mean and variance
popmn<-mean(Nicotine)
popvar<-var(Nicotine)

#getting 30 samples of size 5 and calculate sample mean and variance
samples<-c()
n<-c()
#using the for loop to get a sample size of 5 with or without replacement
for(i in 1:30){
  s<-sample(Nicotine,5,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}
#assigning column names for each sample
colnames(samples)=n
#we can use apply to calculate any function like mean,variance etc.
s.means<-apply(samples,2,mean)
s.means
s.vars<-apply(samples,2,var)
s.vars

#calculate the mean and variance of sample means
samplemean<-mean(s.means)
samplevars<-var(s.means)

#compare population and sample mean
popmn
samplemean
#compare population variance and sample means variance
truevar=popvar/5
samplevars


#Exercise
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)
fix(data)
attach(data)

#question - 1
popmn<-mean(Weight.kg.)
popvar<-var(Weight.kg.)
popmn
popvar
standard_deviation= sqrt(popvar)
standard_deviation


#question - 2
#getting 25 samples of size 6
samples<-c()
n<-c()
#using the for loop to get a sample size of 5 with or without replacement
for(i in 1:25){
  s<-sample(Nicotine,6,replace=TRUE)
  samples<-cbind(samples,s)
  n<-c(n,paste('S',i))
}
#assigning column names for each sample
colnames(samples)=n
#we can use apply to calculate any function like mean,variance etc.
s.means<-apply(samples,2,mean)
s.vars<-apply(samples,2,var)
s.means
s.vars


#question - 3
samplemean<-mean(s.means)
samplevars<-var(s.means)

popmn
samplemean

truevar=popvar/6
samplevars
truevar
truesd=sqrt(truevar)
truesd
truemean=popmn/6
truemean
